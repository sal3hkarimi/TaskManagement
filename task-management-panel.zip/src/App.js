import "./styles/css/style.css";
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon, Cog6ToothIcon, EyeIcon, Squares2X2Icon } from "@heroicons/react/24/outline";
import PicProfile from "./assets/images/calendar/pic-profile.jpg";

const MenuBoardIcon = () => (<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M16.3809 22.7502H3.2409C2.2909 22.7502 1.41091 22.3103 0.840908 21.5403C0.260908 20.7603 0.0909169 19.7802 0.380917 18.8502L4.59091 5.32019C4.97091 4.06019 6.13092 3.2002 7.45092 3.2002H19.7509C20.9609 3.2002 22.0509 3.92028 22.5109 5.04028C22.7609 5.62028 22.8109 6.2803 22.6609 6.9303L19.2909 20.4602C18.9709 21.8102 17.7709 22.7502 16.3809 22.7502ZM7.4609 4.71021C6.8109 4.71021 6.22091 5.14026 6.03091 5.77026L1.82092 19.3003C1.68092 19.7703 1.76091 20.2603 2.06091 20.6603C2.34091 21.0403 2.78091 21.2603 3.25091 21.2603H16.3909C17.0809 21.2603 17.6809 20.7902 17.8409 20.1202L21.2109 6.5802C21.2909 6.2502 21.2709 5.92025 21.1409 5.63025C20.9009 5.06025 20.3709 4.7002 19.7609 4.7002H7.4609V4.71021Z" fill="currentColor" />
  <path d="M20.78 22.75H16C15.59 22.75 15.25 22.41 15.25 22C15.25 21.59 15.59 21.25 16 21.25H20.78C21.19 21.25 21.57 21.08 21.85 20.78C22.13 20.48 22.27 20.08 22.24 19.67L21.25 6.05002C21.22 5.64002 21.53 5.27997 21.94 5.24997C22.35 5.22997 22.71 5.52991 22.74 5.93991L23.73 19.56C23.79 20.38 23.5 21.2 22.94 21.8C22.39 22.41 21.6 22.75 20.78 22.75Z" fill="currentColor" />
  <path d="M9.67977 7.12971C9.61977 7.12971 9.55977 7.11969 9.49977 7.10969C9.09977 7.00969 8.84979 6.60966 8.94979 6.19966L9.98976 1.87971C10.0898 1.47971 10.4898 1.22966 10.8998 1.32966C11.2998 1.42966 11.5498 1.8297 11.4498 2.2397L10.4098 6.55977C10.3298 6.89977 10.0198 7.12971 9.67977 7.12971Z" fill="currentColor" />
  <path d="M16.3795 7.13974C16.3295 7.13974 16.2694 7.13972 16.2194 7.11972C15.8194 7.02972 15.5595 6.62971 15.6395 6.22971L16.5794 1.88974C16.6694 1.47974 17.0694 1.22979 17.4694 1.30979C17.8694 1.38979 18.1294 1.79968 18.0494 2.19968L17.1094 6.53977C17.0394 6.89977 16.7295 7.13974 16.3795 7.13974Z" fill="currentColor" />
  <path d="M15.6992 12.75H7.69922C7.28922 12.75 6.94922 12.41 6.94922 12C6.94922 11.59 7.28922 11.25 7.69922 11.25H15.6992C16.1092 11.25 16.4492 11.59 16.4492 12C16.4492 12.41 16.1092 12.75 15.6992 12.75Z" fill="currentColor" />
  <path d="M14.6992 16.75H6.69922C6.28922 16.75 5.94922 16.41 5.94922 16C5.94922 15.59 6.28922 15.25 6.69922 15.25H14.6992C15.1092 15.25 15.4492 15.59 15.4492 16C15.4492 16.41 15.1092 16.75 14.6992 16.75Z" fill="currentColor" />
</svg>)

const CalendarIcon = () => (<svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M8 5.75C7.59 5.75 7.25 5.41 7.25 5V2C7.25 1.59 7.59 1.25 8 1.25C8.41 1.25 8.75 1.59 8.75 2V5C8.75 5.41 8.41 5.75 8 5.75Z" fill="currentColor" />
  <path d="M16 5.75C15.59 5.75 15.25 5.41 15.25 5V2C15.25 1.59 15.59 1.25 16 1.25C16.41 1.25 16.75 1.59 16.75 2V5C16.75 5.41 16.41 5.75 16 5.75Z" fill="currentColor" />
  <path d="M8.5 14.5001C8.37 14.5001 8.24 14.4701 8.12 14.4201C7.99 14.3701 7.89 14.3001 7.79 14.2101C7.61 14.0201 7.5 13.7701 7.5 13.5001C7.5 13.3701 7.53 13.2401 7.58 13.1201C7.63 13.0001 7.7 12.8901 7.79 12.7901C7.89 12.7001 7.99 12.6301 8.12 12.5801C8.48 12.4301 8.93 12.5101 9.21 12.7901C9.39 12.9801 9.5 13.2401 9.5 13.5001C9.5 13.5601 9.49 13.6301 9.48 13.7001C9.47 13.7601 9.45 13.8201 9.42 13.8801C9.4 13.9401 9.37 14.0001 9.33 14.0601C9.3 14.1101 9.25 14.1601 9.21 14.2101C9.02 14.3901 8.76 14.5001 8.5 14.5001Z" fill="currentColor" />
  <path d="M12 14.4999C11.87 14.4999 11.74 14.4699 11.62 14.4199C11.49 14.3699 11.39 14.2999 11.29 14.2099C11.11 14.0199 11 13.7699 11 13.4999C11 13.3699 11.03 13.2399 11.08 13.1199C11.13 12.9999 11.2 12.8899 11.29 12.7899C11.39 12.6999 11.49 12.6299 11.62 12.5799C11.98 12.4199 12.43 12.5099 12.71 12.7899C12.89 12.9799 13 13.2399 13 13.4999C13 13.5599 12.99 13.6299 12.98 13.6999C12.97 13.7599 12.95 13.8199 12.92 13.8799C12.9 13.9399 12.87 13.9999 12.83 14.0599C12.8 14.1099 12.75 14.1599 12.71 14.2099C12.52 14.3899 12.26 14.4999 12 14.4999Z" fill="currentColor" />
  <path d="M15.5 14.4999C15.37 14.4999 15.24 14.4699 15.12 14.4199C14.99 14.3699 14.89 14.2999 14.79 14.2099C14.75 14.1599 14.71 14.1099 14.67 14.0599C14.63 13.9999 14.6 13.9399 14.58 13.8799C14.55 13.8199 14.53 13.7599 14.52 13.6999C14.51 13.6299 14.5 13.5599 14.5 13.4999C14.5 13.2399 14.61 12.9799 14.79 12.7899C14.89 12.6999 14.99 12.6299 15.12 12.5799C15.49 12.4199 15.93 12.5099 16.21 12.7899C16.39 12.9799 16.5 13.2399 16.5 13.4999C16.5 13.5599 16.49 13.6299 16.48 13.6999C16.47 13.7599 16.45 13.8199 16.42 13.8799C16.4 13.9399 16.37 13.9999 16.33 14.0599C16.3 14.1099 16.25 14.1599 16.21 14.2099C16.02 14.3899 15.76 14.4999 15.5 14.4999Z" fill="currentColor" />
  <path d="M8.5 17.9999C8.37 17.9999 8.24 17.97 8.12 17.92C8 17.87 7.89 17.7999 7.79 17.7099C7.61 17.5199 7.5 17.2599 7.5 16.9999C7.5 16.8699 7.53 16.7399 7.58 16.6199C7.63 16.4899 7.7 16.38 7.79 16.29C8.16 15.92 8.84 15.92 9.21 16.29C9.39 16.48 9.5 16.7399 9.5 16.9999C9.5 17.2599 9.39 17.5199 9.21 17.7099C9.02 17.8899 8.76 17.9999 8.5 17.9999Z" fill="currentColor" />
  <path d="M12 17.9999C11.74 17.9999 11.48 17.8899 11.29 17.7099C11.11 17.5199 11 17.2599 11 16.9999C11 16.8699 11.03 16.7399 11.08 16.6199C11.13 16.4899 11.2 16.38 11.29 16.29C11.66 15.92 12.34 15.92 12.71 16.29C12.8 16.38 12.87 16.4899 12.92 16.6199C12.97 16.7399 13 16.8699 13 16.9999C13 17.2599 12.89 17.5199 12.71 17.7099C12.52 17.8899 12.26 17.9999 12 17.9999Z" fill="currentColor" />
  <path d="M15.5 17.9999C15.24 17.9999 14.98 17.8899 14.79 17.7099C14.7 17.6199 14.63 17.5099 14.58 17.3799C14.53 17.2599 14.5 17.1299 14.5 16.9999C14.5 16.8699 14.53 16.7399 14.58 16.6199C14.63 16.4899 14.7 16.3799 14.79 16.2899C15.02 16.0599 15.37 15.9499 15.69 16.0199C15.76 16.0299 15.82 16.0499 15.88 16.0799C15.94 16.0999 16 16.1299 16.06 16.1699C16.11 16.1999 16.16 16.2499 16.21 16.2899C16.39 16.4799 16.5 16.7399 16.5 16.9999C16.5 17.2599 16.39 17.5199 16.21 17.7099C16.02 17.8899 15.76 17.9999 15.5 17.9999Z" fill="currentColor" />
  <path d="M20.5 9.83984H3.5C3.09 9.83984 2.75 9.49984 2.75 9.08984C2.75 8.67984 3.09 8.33984 3.5 8.33984H20.5C20.91 8.33984 21.25 8.67984 21.25 9.08984C21.25 9.49984 20.91 9.83984 20.5 9.83984Z" fill="currentColor" />
  <path d="M16 22.75H8C4.35 22.75 2.25 20.65 2.25 17V8.5C2.25 4.85 4.35 2.75 8 2.75H16C19.65 2.75 21.75 4.85 21.75 8.5V17C21.75 20.65 19.65 22.75 16 22.75ZM8 4.25C5.14 4.25 3.75 5.64 3.75 8.5V17C3.75 19.86 5.14 21.25 8 21.25H16C18.86 21.25 20.25 19.86 20.25 17V8.5C20.25 5.64 18.86 4.25 16 4.25H8Z" fill="currentColor" />
</svg>)

function App() {

  console.log(CalendarIcon);
  console.log(Cog6ToothIcon);
  return (
    <div className="App">
      <div className="navbar">
        <div className="profile">
          <div className="box-img">
            <img src={PicProfile} alt="profile img" />
          </div>
          <p>عظیم کریمی</p>
          <div className="icon-box">
            <ChevronDownIcon />
          </div>
        </div>
      </div>
      <div className="calendar-warpper">
        <div className="box-calendar">
          <div className="sidebar">
            <div className="icon-box"><Squares2X2Icon /></div>
            <div className="icon-box"><MenuBoardIcon /></div>
            <div className="icon-box"><CalendarIcon /></div>
            <div className="icon-box"><Cog6ToothIcon /></div>
          </div>
          <div className="main-calendar">

            <div className="todo-tasks">
              <div className="title-task">
                <h5>تسک‌های امروز</h5>
                <span>۴</span>
              </div>
              <div className="tasks">
                <div className="task">
                  <div className="box-task">
                    <div className="icon-box"><MenuBoardIcon /></div>
                    <p>بررسی کابل برق</p>
                  </div>
                  <div className="icon-box"><EyeIcon /></div>
                </div>
                <div className="task">
                  <div className="box-task">
                    <div className="icon-box"><MenuBoardIcon /></div>
                    <p>بررسی کابل برق</p>
                  </div>
                  <div className="icon-box"><EyeIcon /></div>
                </div>
                <div className="task">
                  <div className="box-task">
                    <div className="icon-box"><MenuBoardIcon /></div>
                    <p>بررسی کابل برق</p>
                  </div>
                  <div className="icon-box"><EyeIcon /></div>
                </div>
                <div className="task">
                  <div className="box-task">
                    <div className="icon-box"><MenuBoardIcon /></div>
                    <p>بررسی کابل برق</p>
                  </div>
                  <div className="icon-box"><EyeIcon /></div>
                </div>
              </div>
            </div>
            <div className="break-line"></div>

            <div className="calendar">
              <div className="calendar-title">
                <div className="icon-box"><CalendarIcon /></div>
                <h5>تقویم</h5>
              </div>

              <div className="mouth">
                <h6>دی ۱۴۰۱</h6>
                <div className="arrows">
                  <div className="icon-box"><ChevronRightIcon /></div>
                  <div className="icon-box"><ChevronLeftIcon /></div>
                </div>
              </div>

              <div className="cal-table">
                <div className="cal-column">
                  <div className="name-week">شنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">یکشنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">دوشنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">سه شنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">چهارشنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">پنج شنبه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
                <div className="cal-column">
                  <div className="name-week">جمعه</div>
                  <div className="day">۱</div>
                  <div className="day">۲</div>
                  <div className="day">۳</div>
                  <div className="day">۴</div>
                </div>
              </div>

            </div>
            <div className="calendar-container">


            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
